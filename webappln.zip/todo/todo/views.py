from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from todo.models import TODOO, Problem, Profile
from collections import Counter
from django.shortcuts import render
from todo.models import Problem 
from django.shortcuts import render
from django.utils.timezone import now, timedelta
from collections import defaultdict
from todo.models import Problem
from django.db.models.functions import TruncDate
from django.db.models import Count
from todo.models import models

def signup(request):
    if request.method == "POST":
        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken!")
        elif User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered!")
        else:
            User.objects.create_user(username=username, email=email, password=password)
            messages.success(request, "Signup successful! You can now log in.")
            return redirect("loginn")  # Redirect to login page after signup

    return render(request, "signup.html")

def loginn(request):
    if request.method == 'POST':
        fnm = request.POST.get('fnm')
        pwd = request.POST.get('pwd')
        userr = authenticate(request, username=fnm, password=pwd)
        if userr is not None:
            login(request, userr)
            return redirect('/home')
        else:
            messages.error(request, "Invalid username or password. Please try again.")
            return redirect('/loginn')

    return render(request, 'loginn.html')


@login_required(login_url='/loginn')
def user_profile(request):
    user = request.user
    profile, created = Profile.objects.get_or_create(user=user)

    problems_solved = Problem.objects.filter(user=user).count()
    rank = problems_solved  # You can update ranking logic here

    context = {
        'name': user.username,
        'email': user.email,
        'phone': profile.phone if profile.phone else "N/A",
        'address': profile.address if profile.address else "N/A",
        'problems_solved': problems_solved,
        'rank': rank,
    }
    return render(request, 'profile.html', context)

from django.http import JsonResponse

import json  # Add this import at the top

def profile_view(request):
    user = request.user

    # Pie Chart Data: Count problems by difficulty
    problems = Problem.objects.filter(user=user, status="Solved")
    difficulties = [p.difficulty for p in problems]
    pie_data = json.dumps(dict(Counter(difficulties)))  # Convert to JSON format

    # Line Chart Data: Problems solved per day (last 30 days)
    last_week = now() - timedelta(days=30)
    daily_counts = (
        Problem.objects.filter(user=user, status="Solved", created_at__gte=last_week)
        .annotate(date=TruncDate('created_at'))
        .values('date')
        .annotate(count=Count('id'))
        .order_by('date')
    )

    # Convert queryset to JSON dictionary format
    line_data = json.dumps({entry['date'].strftime('%Y-%m-%d'): entry['count'] for entry in daily_counts})

    return render(request, 'profile.html', {'pie_data': pie_data, 'line_data': line_data})



def add_problem(request):
    if request.method == "POST":
        problem_name = request.POST.get("problem_name")
        problem_link = request.POST.get("problem_link")
        platform = request.POST.get("platform")
        status = request.POST.get("status")
        domain = request.POST.get("domain")
        difficulty = request.POST.get("difficulty")

        # Assign points based on difficulty
        score_mapping = {"Easy": 20, "Medium": 50, "Hard": 100}
        points = score_mapping.get(difficulty, 0)

        # Save the problem to the database
        Problem.objects.create(
            user=request.user,
            problem_name=problem_name,
            problem_link=problem_link,
            platform=platform,
            status=status,
            domain=domain,
            difficulty=difficulty
        )

        # Ensure Profile exists and update the score
        profile, created = Profile.objects.get_or_create(user=request.user)
        profile.score += points
        profile.save()

    problems = Problem.objects.filter(user=request.user)  # Show only user’s problems
    return render(request, "add_problem.html", {"problems": problems})


@login_required(login_url='/loginn')
def home(request):
    return render(request, 'home.html')


@login_required(login_url='/loginn')
def dashboard(request):
    users = Profile.objects.select_related("user").order_by("-score")

    leaderboard = []
    for user in users:
        easy_count = Problem.objects.filter(user=user.user, difficulty="Easy", status="Solved").count()
        medium_count = Problem.objects.filter(user=user.user, difficulty="Medium", status="Solved").count()
        hard_count = Problem.objects.filter(user=user.user, difficulty="Hard", status="Solved").count()

        easy_score = easy_count * 20
        medium_score = medium_count * 50
        hard_score = hard_count * 100

        leaderboard.append({
            "user": user,
            "rank": 0,  # We'll update this later
            "easy": easy_count,
            "medium": medium_count,
            "hard": hard_count,
            "easy_score": easy_score,
            "medium_score": medium_score,
            "hard_score": hard_score,
        })

    # Assign ranks based on total score
    leaderboard = sorted(leaderboard, key=lambda x: x["user"].score, reverse=True)
    
    rank = 1
    prev_score = None
    for entry in leaderboard:
        if prev_score is not None and entry["user"].score < prev_score:
            rank += 1
        entry["rank"] = rank
        prev_score = entry["user"].score

    return render(request, "dashboard.html", {"leaderboard": leaderboard})



@login_required(login_url='/loginn')
def delete_problem(request, problem_id):
    problem = get_object_or_404(Problem, id=problem_id, user=request.user)
    
    difficulty = problem.difficulty
    score_mapping = {"Easy": 20, "Medium": 50, "Hard": 100}
    points = score_mapping.get(difficulty, 0)
    problem.delete()
    profile, created = Profile.objects.get_or_create(user=request.user)
    profile.score -= points
    profile.save()

    return redirect('/add_problem')  # Redirect back to the problem list


from django.shortcuts import render
from .models import Problem
from django.utils import timezone
from django.db.models.functions import TruncDate
from django.db.models import Count
from datetime import timedelta

def analysis_view(request):
    today = timezone.now().date()
    start_date = today - timedelta(days=29)  # last 30 days including today

    # Problems today
    problems_today = Problem.objects.filter(created_at__date=today)
    easy_total = problems_today.filter(difficulty='Easy').count()
    medium_total = problems_today.filter(difficulty='Medium').count()
    hard_total = problems_today.filter(difficulty='Hard').count()

    # Line chart data
    last_30_days_data = (
        Problem.objects
        .filter(created_at__date__gte=start_date, created_at__date__lte=today)
        .annotate(date=TruncDate('created_at'))
        .values('date')
        .annotate(count=Count('id'))
        .order_by('date')
    )

    # Prepare chart data
    date_count_map = {entry['date']: entry['count'] for entry in last_30_days_data}
    all_dates = [start_date + timedelta(days=i) for i in range(30)]
    labels = [d.strftime('%Y-%m-%d') for d in all_dates]
    data = [date_count_map.get(d, 0) for d in all_dates]

    context = {
        'easy_total': easy_total,
        'medium_total': medium_total,
        'hard_total': hard_total,
        'total_today': easy_total + medium_total + hard_total,
        'labels': labels,
        'data': data,
    }

    return render(request, 'analysis.html', context)



def signout(request):
    logout(request)
    return redirect('/loginn')
