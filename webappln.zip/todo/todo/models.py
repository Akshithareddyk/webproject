from django.db import models
from django.contrib.auth.models import User

# Extending User model using One-to-One relationship
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    problems_solved = models.IntegerField(default=0)
    rank = models.IntegerField(default=0)

    def __str__(self):
        return self.user.username

# Keeping existing TODOO model
class TODOO(models.Model):
    srno = models.AutoField(auto_created=True, primary_key=True)
    title = models.CharField(max_length=25)
    date = models.DateTimeField(auto_now_add=True)
    status = models.BooleanField(default=False, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)

# New model to store user problems
class Problem(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    problem_name = models.CharField(max_length=100)
    problem_link = models.URLField()
    platform = models.CharField(max_length=50)  # Example: Leetcode, Codeforces
    status = models.CharField(max_length=20, choices=[('Solved', 'Solved'), ('Attempted', 'Attempted')])
    domain = models.CharField(max_length=50)  # Example: Graph, DP, Greedy
    difficulty = models.CharField(
        max_length=10,
        choices=[('Easy', 'Easy'), ('Medium', 'Medium'), ('Hard', 'Hard')],
        default='Easy'
    )
    created_at = models.DateTimeField(auto_now_add=True)  # NEW FIELD

    def __str__(self):
        return f"{self.problem_name} - {self.difficulty}"
    
# Updated Profile model with address
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone = models.CharField(max_length=15, blank=True, null=True)  # Ensure phone number is optional
    address = models.TextField(blank=True, null=True)  # Ensure address is optional
    em = models.EmailField(unique=False, default="default@example.com")  # Set a default email
    score = models.IntegerField(default=0)

class ProblemSolveRecord(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)

    easy_count = models.IntegerField(default=0)
    medium_count = models.IntegerField(default=0)
    hard_count = models.IntegerField(default=0)

    def total(self):
        return self.easy_count + self.medium_count + self.hard_count

    def __str__(self):
        return self.user.username