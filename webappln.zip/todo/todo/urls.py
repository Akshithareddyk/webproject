from . import views
from .views import delete_problem
from django.contrib import admin
from django.urls import path ,include
from django.urls import path
from todo.views import profile_view 

urlpatterns = [
    path('', views.loginn, name='loginn'),
    path('loginn/', views.loginn, name='loginn'),
    path('signup/', views.signup, name='signup'),
    path('home/', views.home, name='home'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('profile/', profile_view, name='profile'),  # Only keep one profile path
    path('add_problem/', views.add_problem, name='add_problem'),
    path('delete_problem/<int:problem_id>/', delete_problem, name='delete_problem'),
    path('analysis/', views.analysis_view, name='analysis_page'),
]
